(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.5688fe5b.js")
    );
  })().catch(console.error);

})();
