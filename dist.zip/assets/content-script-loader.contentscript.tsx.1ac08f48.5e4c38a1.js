(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.1ac08f48.js")
    );
  })().catch(console.error);

})();
