(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.b7d5d63b.js")
    );
  })().catch(console.error);

})();
