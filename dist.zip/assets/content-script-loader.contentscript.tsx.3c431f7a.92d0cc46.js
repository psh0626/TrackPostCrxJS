(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.3c431f7a.js")
    );
  })().catch(console.error);

})();
