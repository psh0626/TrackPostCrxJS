(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.ec7131a1.js")
    );
  })().catch(console.error);

})();
