(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.71d4dc2a.js")
    );
  })().catch(console.error);

})();
