(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.b2b18fc4.js")
    );
  })().catch(console.error);

})();
