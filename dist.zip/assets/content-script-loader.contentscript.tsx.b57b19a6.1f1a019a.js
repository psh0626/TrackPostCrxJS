(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.b57b19a6.js")
    );
  })().catch(console.error);

})();
