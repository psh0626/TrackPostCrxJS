(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.5c1dcf5a.js")
    );
  })().catch(console.error);

})();
