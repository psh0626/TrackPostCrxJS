(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.2e0b7c3c.js")
    );
  })().catch(console.error);

})();
