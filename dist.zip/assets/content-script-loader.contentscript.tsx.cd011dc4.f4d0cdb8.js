(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.cd011dc4.js")
    );
  })().catch(console.error);

})();
