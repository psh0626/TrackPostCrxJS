(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.ed5dc83e.js")
    );
  })().catch(console.error);

})();
