(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.cf5194b4.js")
    );
  })().catch(console.error);

})();
