(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.bf17ef68.js")
    );
  })().catch(console.error);

})();
