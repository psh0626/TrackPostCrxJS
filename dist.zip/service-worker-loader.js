import './assets/serviceworker.ts.4315e61a.js';
