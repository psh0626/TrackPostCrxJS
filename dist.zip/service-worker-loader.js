import './assets/serviceworker.ts.855a0ab3.js';
