import './assets/serviceworker.ts.44dd6fbd.js';
