import './assets/serviceworker.ts.5486864d.js';
