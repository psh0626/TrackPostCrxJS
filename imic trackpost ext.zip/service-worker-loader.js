import './assets/serviceworker.ts.f8aff0a9.js';
