(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.1fdf62d2.js")
    );
  })().catch(console.error);

})();
